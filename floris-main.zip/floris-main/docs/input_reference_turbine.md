# Turbine Input File Reference

The turbine input file is an optional input used to define a custom turbine type.
The file must be YAML format with either "yaml" or "yml" extension. See
for more information on inspecting and creating the turbine definition.

```{eval-rst}
.. autoyaml:: docs/nrel_5MW.yaml
```
